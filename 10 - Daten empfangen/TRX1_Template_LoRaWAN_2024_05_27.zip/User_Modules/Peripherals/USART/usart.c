/**
  ******************************************************************************
  * @file    usart.c
  * @brief   This file provides code for the configuration
  *          of the USART instances.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under Ultimate Liberty license
  * SLA0044, the "License"; You may not use this file except in compliance with
  * the License. You may obtain a copy of the License at:
  *                             www.st.com/SLA0044
  *
  ******************************************************************************
  */

/* Includes ------------------------------------------------------------------*/
#include "usart.h"
#include "stm32wlxx_ll_usart.h"
#include "sys_app.h"
#include "hw_conf.h"

UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;

/* USART1 init function */
void MX_USART1_UART_Init( void )
{
  huart1.Instance                     = USART1;
  huart1.Init.BaudRate                = USART1_BAUDRATE;
  huart1.Init.WordLength              = UART_WORDLENGTH_8B;
  huart1.Init.StopBits                = UART_STOPBITS_1;
  huart1.Init.Parity                  = UART_PARITY_NONE;
  huart1.Init.Mode                    = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl               = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling            = UART_OVERSAMPLING_16;
  huart1.Init.OneBitSampling          = UART_ONE_BIT_SAMPLE_DISABLE;
  huart1.Init.ClockPrescaler          = UART_PRESCALER_DIV1;
  huart1.AdvancedInit.AdvFeatureInit  = UART_ADVFEATURE_NO_INIT;

  if( HAL_UART_Init( &huart1 ) != HAL_OK )
  {
    Error_Handler();
  }

  if( HAL_UARTEx_SetTxFifoThreshold( &huart1, UART_TXFIFO_THRESHOLD_1_8 ) != HAL_OK )
  {
    Error_Handler();
  }

  if( HAL_UARTEx_SetRxFifoThreshold( &huart1, UART_RXFIFO_THRESHOLD_1_8 ) != HAL_OK )
  {
    Error_Handler();
  }

  if( HAL_UARTEx_DisableFifoMode( &huart1 ) != HAL_OK )
  {
    Error_Handler();
  }
}

void HAL_UART_MspInit( UART_HandleTypeDef* uartHandle )
{
  GPIO_InitTypeDef GPIO_InitStruct              = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct  = {0};

  if( uartHandle->Instance == USART1 )
  {
    /** Initializes the peripherals clocks */
    PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_USART1;
    PeriphClkInitStruct.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK2;

    if( HAL_RCCEx_PeriphCLKConfig( &PeriphClkInitStruct ) != HAL_OK )
    {
      Error_Handler();
    }

    /* USART1 clock enable */
    __HAL_RCC_USART1_CLK_ENABLE();
    
    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**USART1 GPIO Configuration
    PA10     ------> USART1_RX
    PA9     ------> USART1_TX
    */
    GPIO_InitStruct.Pin       = USART1_RX_Pin | USART1_TX_Pin;
    GPIO_InitStruct.Mode      = GPIO_MODE_AF_PP;
    GPIO_InitStruct.Pull      = GPIO_PULLUP;
    GPIO_InitStruct.Speed     = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF7_USART1;
    HAL_GPIO_Init( GPIOA, &GPIO_InitStruct );
  }
  else if( uartHandle->Instance == USART2 )
  {
    // ...
  }
}

void HAL_UART_MspDeInit( UART_HandleTypeDef* uartHandle )
{
  if( uartHandle->Instance == USART1 )
  {
    __HAL_RCC_USART1_CLK_DISABLE();

    /**USART2 GPIO Configuration
    PA10     ------> USART1_RX
    PA9      ------> USART1_TX
    */
    HAL_GPIO_DeInit( GPIOA, USART1_RX_Pin | USART1_TX_Pin );
  }
  else if( uartHandle->Instance == USART2 )
  {
    // ...
  }
}
